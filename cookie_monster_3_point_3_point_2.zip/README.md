# Cookie Monster Version 1

The first version of this project will only be able to peform the following operations in order of priority:

1. Reject All on External Banner
2. Manage Preferences on External Banner, Reject All on Internal Banner
3. Accept All

Made in collaboration with GPT-4o and GPT-3.5.
